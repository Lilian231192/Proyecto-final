document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    updateUI();
});

function updateUI() {
    const welcomeMessage = document.getElementById('welcomeMessage');
    const preferencesCard = document.getElementById('preferencesCard');
    const adminCard = document.getElementById('adminCard');
    const loginLink = document.querySelector('nav ul li:last-child a');

    if (isLoggedIn) {
        welcomeMessage.innerHTML = `<p>Bienvenido, ${username}!</p>`;
        preferencesCard.style.display = 'block';
        loginLink.textContent = 'Cerrar sesión';
        loginLink.href = '#';
        loginLink.onclick = function(e) {
            e.preventDefault();
            logout();
            window.location.reload();
        };

        if (isAdmin) {
            adminCard.style.display = 'block';
        }
    } else {
        welcomeMessage.innerHTML = '';
        preferencesCard.style.display = 'none';
        adminCard.style.display = 'none';
        loginLink.textContent = 'Iniciar sesión / Registrarse';
        loginLink.href = 'login.html';
        loginLink.onclick = null;
    }
}

