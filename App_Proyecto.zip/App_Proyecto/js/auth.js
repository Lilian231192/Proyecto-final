// Simulated authentication state
let isLoggedIn = false;
let isAdmin = false;
let username = '';

// Simulated user database
let users = [
    { username: 'admin', password: 'admin123', email: 'admin@example.com', isAdmin: true },
    { username: 'user', password: 'user123', email: 'user@example.com', isAdmin: false }
];

function checkAuth() {
    // In a real application, you would check with a server here
    // For now, we'll just use localStorage to simulate authentication
    isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    isAdmin = localStorage.getItem('isAdmin') === 'true';
    username = localStorage.getItem('username') || '';
}

function login(user, pass) {
    const foundUser = users.find(u => u.username === user && u.password === pass);
    if (foundUser) {
        isLoggedIn = true;
        isAdmin = foundUser.isAdmin;
        username = foundUser.username;

        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('isAdmin', isAdmin ? 'true' : 'false');
        localStorage.setItem('username', username);
        return true;
    }
    return false;
}

function logout() {
    isLoggedIn = false;
    isAdmin = false;
    username = '';
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('isAdmin');
    localStorage.removeItem('username');
}

function register(user, email, pass) {
    if (users.some(u => u.username === user)) {
        return false; // Username already exists
    }
    users.push({ username: user, password: pass, email: email, isAdmin: false });
    return true;
}

